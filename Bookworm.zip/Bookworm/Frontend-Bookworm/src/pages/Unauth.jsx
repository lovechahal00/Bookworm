import Unauthorized from "../components/Unauthorized";

const Unauth = () => {
  return <Unauthorized />;
};

export default Unauth;
