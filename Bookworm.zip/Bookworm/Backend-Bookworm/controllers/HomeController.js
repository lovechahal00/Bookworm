module.exports.home = (req, res) => {
  res.send(`<h1> ** BookStore API ** </h1>`);
};
